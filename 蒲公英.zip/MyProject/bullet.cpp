#include "DxLib.h"
#include "main.h"
#include "keycheck.h"
#include "bullet.h"
#include "player.h"

// �ϐ��錾
int bulletImage;
CHARACTER bullet[BULLET_MAX];



// �G�e�摜������
void BulletSystemInit(void)
{
	bulletImage = LoadGraph("image/eshot.png");
}

// �G�e�ϐ�������
void BulletGameInit(void)
{
	// ��а���Ă̕ϐ�
	for (int i = 0; i < BULLET_MAX; i++) {
		bullet[i].visible = false;
		bullet[i].pos = { 0,0 };
		bullet[i].size = { 16,16 };
		bullet[i].sizeOffset = { bullet[i].size.x / 2, bullet[i].size.y / 2 };
		bullet[i].moveSpeed = 3;
		bullet[i].MovCnt = 0;
		bullet[i].angle = 0;
		bullet[i].mov = { 0, 0 };
	}
}

// �G�e����
void BulletControl(void)
{
/*	for (int i = 0; i < BULLET_MAX; i++) {
		if (bullet[i].visible) {
			bullet[i].MovCnt++;
			if (bullet[i].MovCnt > 120) {
				XY vector[2];
				vector[0].x = cos(bullet[i].angle);
				vector[0].y = sin(bullet[i].angle);
				vector[1].x = player.pos.x - bullet[i].pos.x;
				vector[1].y = player.pos.y - bullet[i].pos.y;

				float tmpCross;
				tmpCross = ((vector[0].x * vector[1].y) - (vector[0].y * vector[1].x));
				if (tmpCross > 0) bullet[i].angle += (PI / 180) + 5;
				if (tmpCross < 0) bullet[i].angle -= (PI / 180) + 5;

				bullet[i].mov.x = cos(bullet[i].angle)*bullet[i].moveSpeed;
				bullet[i].mov.y = sin(bullet[i].angle)*bullet[i].moveSpeed;
			}
		}
	}*/


	// �e�̈ړ�(��а)
	for (int i = 0; i < BULLET_MAX; i++) {
		if (bullet[i].visible) {
//			bullet[i].pos.x -= bullet[i].mov.x;
//			bullet[i].pos.y -= bullet[i].mov.y;
			bullet[i].pos.x += bullet[i].speed.x;
			bullet[i].pos.y += bullet[i].speed.y;
			if ((bullet[i].pos.x > SCREEN_SIZE_X - 160)
			  ||(bullet[i].pos.x < 0)
			  ||(bullet[i].pos.y > SCREEN_SIZE_Y)
			  ||(bullet[i].pos.y < 0)) 
			{
//				bullet[i].MovCnt = 0;
				bullet[i].visible = false;
			}
		}
	}
}

// �e�̔���(��а)
void EShoot(XY_F ePos)
{
	for (int i = 0; i < BULLET_MAX; i++) {
		if (!bullet[i].visible) {
			bullet[i].pos = { ePos.x , ePos.y };
			bullet[i].visible = true;
			bullet[i].speed.x = 1;
			bullet[i].speed.y = 1;
		}
	}
}

// �G�e�`��
void BulletDraw(void)
{
	// ��а�̒e
	for (int i = 0; i < BULLET_MAX; i++) {
		if (bullet[i].visible){
			DrawGraph(bullet[i].pos.x - bullet[i].sizeOffset.x,
				bullet[i].pos.y - bullet[i].sizeOffset.y, bulletImage, true);
		}
	}

	for (int i = 0; i < BULLET_MAX; i++) {
//		DrawFormatString(0, 0, 0xffffff,"Count = %d" ,bullet[i].MovCnt);
	}

}