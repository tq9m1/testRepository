#include <math.h>
#include "DxLib.h"
#include "main.h"
#include "keycheck.h"
#include "enemy.h"
#include "bullet.h"
#include "player.h"
#include "blast.h"

// �ϐ�
int enemyImage;
CHARACTER enemy[ENEMY_MAX];

int enemyCounter;

int deathSe;

// �摜������
void EnemySystemInit(void)
{
	enemyImage = LoadGraph("image/enemy.png");

	deathSe = LoadSoundMem("bgm/shoot1.mp3");
}

// �G�̒ǉ�����
void EnemyAdd(void)
{
	for (int i = 0; i < ENEMY_MAX; i++) {
		if (enemy[i].visible)
			continue;
		enemy[i].visible = true;
		enemy[i].size = { 52,50 };
		enemy[i].sizeOffset = { enemy[i].size.x / 2, enemy[i].size.y / 2 };
		enemy[i].pos = { SCREEN_SIZE_X / 2, 0 };
		enemy[i].pos.x = GetRand(SCREEN_SIZE_X - 160 - enemy[i].size.x);
		enemy[i].pos.y = -enemy[i].sizeOffset.y;
		enemy[i].moveSpeed = 2;
		enemy[i].animCnt = 0;
		enemy[i].damageFlag = false;
		enemy[i].shotFlag = false;
		enemy[i].point = 100;
		enemy[i].MovCnt = 0;
		return;
	}
}

// �ϐ�������
void EnemyGameInit(void)
{
	// �G�̊�b�ϐ�������
	for (int i = 0; i < ENEMY_MAX; i++){
		enemy[i].visible = false;
		enemy[i].size = { 52,50 };
		enemy[i].sizeOffset = { enemy[i].size.x / 2, enemy[i].size.y / 2 };
		enemy[i].pos = { SCREEN_SIZE_X / 2, 0 };			
		enemy[i].pos.x = GetRand(SCREEN_SIZE_X - 160 - enemy[i].size.x);
		enemy[i].pos.y =- enemy[i].sizeOffset.y;
		enemy[i].moveSpeed = 2;
		enemy[i].animCnt = 0;
		enemy[i].damageFlag = false;
		enemy[i].shotFlag = false;
		enemy[i].point = 100;
		enemy[i].MovCnt = 0;
	}

	for (int i = 0; i < 8; i++) {
		EnemyAdd();
	}
}

// �G����
void EnemyControl(void)
{
	// --------- �G�̓���
	for (int i = 0; i < ENEMY_MAX; i++) {
	  // �G�̍��W��70�ȉ��Ȃ�ړ�
		if (enemy[i].pos.y < 70) {
			enemy[i].pos.y += enemy[i].moveSpeed;
		}
		else { // �G�̕\����true���G�e�̕\����false�Ȃ�G���e������
			if ((enemy[i].visible)&&(bullet[i].visible == false)) {
				bullet[i].visible = true;
				bullet[i].pos = enemy[i].pos;
				bullet[i].speed.x = player.pos.x - enemy[i].pos.x;
				bullet[i].speed.y = player.pos.y - enemy[i].pos.y;
				float length = sqrt(bullet[i].speed.x * bullet[i].speed.x + bullet[i].speed.y * bullet[i].speed.y);
				bullet[i].speed.x /= length;
				bullet[i].speed.y /= length;
				bullet[i].speed.x *= bullet[i].moveSpeed;
				bullet[i].speed.y *= bullet[i].moveSpeed;
			}
		}
	}

	enemyCounter++;
	if (enemyCounter % 40 == 0) {
		for (int i = 0; i < 8; i++) {
			EnemyAdd();
		}
	}
}

// �����蔻��
bool EnemyHitCheck(XY_F sPos, XY_F sSize)
{
	for (int i = 0; i < ENEMY_MAX; i++) {
		if ((enemy[i].visible) && (enemy[i].damageFlag == false)) {
			if (((enemy[i].pos.x + enemy[i].sizeOffset.x - 7) >= (sPos.x - sSize.x))
				&& ((enemy[i].pos.x - enemy[i].sizeOffset.x + 7) <= (sPos.x + sSize.x))
				&& ((enemy[i].pos.y + enemy[i].sizeOffset.y - 7) >= (sPos.y - sSize.y))
				&& ((enemy[i].pos.y - enemy[i].sizeOffset.y + 7) <= (sPos.y + sSize.y))) 
			{
				enemy[i].damageFlag = true;
				if(enemy[i].damageFlag == true){
					enemy[i].visible = false;
					AddScore(enemy[i].point);					
					PlaySoundMem(deathSe, DX_PLAYTYPE_BACK);
					ChangeVolumeSoundMem(255 * 70 / 100, deathSe);
					BlastGenerator(enemy[i].pos);
				}
				return true;
			}
		}
	}
	return false;
}

// �`��
void EnemyDraw(void)
{
	for (int i = 0; i < ENEMY_MAX; i++) {
		if(enemy[i].visible){
			DrawGraph(enemy[i].pos.x - enemy[i].sizeOffset.x,
					  enemy[i].pos.y - enemy[i].sizeOffset.y, 
					  enemyImage, true);
		}
	}
/*
	for(int i = 0; i < ENEMY_MAX; i++){
	DrawBox(enemy[i].pos.x - enemy[i].sizeOffset.x+7, enemy[i].pos.y + enemy[i].sizeOffset.y-7,
		enemy[i].pos.x + enemy[i].sizeOffset.x-7, enemy[i].pos.y - enemy[i].sizeOffset.y+7, 0xffffff, false);
	}
*/

//	DrawFormatString(0, 60, 0xffffff, "EnemyPos = %d %d", enemy.pos);
}