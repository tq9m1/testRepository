#include "DxLib.h"
#include "main.h"
#include "keycheck.h"
#include "player.h"
#include "shot.h"

// �ϐ��錾
int playerImage;
CHARACTER player;


// �摜������
void PlayerSystemInit(void)
{
	playerImage = LoadGraph("image/player.png");
}

// �ϐ�������
void PlayerGameInit(void)
{
	player.visible = true;
	player.pos = { SCREEN_SIZE_X / 2 - 72,(SCREEN_SIZE_Y / 2) + 200 };
	player.size = { 32,32 };
	player.sizeOffset = { player.size.x / 2, player.size.y / 2 };
	player.moveSpeed = 6;
	player.life = 10;
	player.lifeMax = player.life;
	player.shotFlag = false;
	player.damageFlag = false;
}

// ���쏈��
void PlayerControl(void)
{
	// ---------- ��ڲ԰����
	bool playerMoved = false;
	// �E�ړ�
	if (newKey[P1_RIGHT]) {
		playerMoved = true;
		player.pos.x += player.moveSpeed;
	}
	// ���ړ�
	if (newKey[P1_LEFT]){
		playerMoved = true;
		player.pos.x -= player.moveSpeed;
	}
	/* ��ړ�
	if (newKey[P1_UP]) {
		playerMoved = true;
		player.pos.y -= player.moveSpeed;
	}
	// ���ړ�
	if (newKey[P1_DOWN]) {
		playerMoved = true;
		player.pos.y += player.moveSpeed;
	}*/

	// ----- �ړ�����
	// �E
	if (player.pos.x > SCREEN_SIZE_X - player.size.x / 2 - 150) {
		player.pos.x = SCREEN_SIZE_X - player.size.x / 2 - 150;
	}
	// ��
	if (player.pos.x < player.size.x / 2) {
		player.pos.x = player.size.x / 2;
	}
	// ��
	if (player.pos.y < player.size.y / 2) {
		player.pos.y = player.size.y / 2;
	}
	// ��
	if (player.pos.y > SCREEN_SIZE_Y - player.size.y / 2) {
		player.pos.y = SCREEN_SIZE_Y - player.size.y / 2;
	}

	/* �e�̔���
	if (newKey[P1_RCTR]) {
		if(player.visible){
			player.shotFlag = true;
			Shoot(player.pos);
			
		}
	}*/
}

// �����蔻��
bool PlayerHitCheck(XY_F ePos, XY_F eSize)
{
	if ((player.visible) && (player.damageFlag == false)) {
		if (((player.pos.x + player.sizeOffset.x - 14) >= (ePos.x - eSize.x))
			&& ((player.pos.x - player.sizeOffset.x + 14) <= (ePos.x + eSize.x))
			&& ((player.pos.y + player.sizeOffset.y - 13) >= (ePos.y - eSize.y))
			&& ((player.pos.y - player.sizeOffset.y + 13) <= (ePos.y + eSize.y)))
		{
			player.damageFlag = true;
			if (player.damageFlag == true) {
				player.visible = false;
			}
			return true;
		}
	}
	return false;
}

// �`�揈��
void PlayerDraw(void)
{
	// ��ڲ԰�̕\��
	if(player.visible){
		DrawGraph(player.pos.x - player.sizeOffset.x,
				  player.pos.y - player.sizeOffset.y, playerImage, true);
	}

/* ----- �����蔻�蒲���p
	DrawBox(player.pos.x - player.sizeOffset.x+14, player.pos.y + player.sizeOffset.y-13,
		player.pos.x + player.sizeOffset.x-14, player.pos.y - player.sizeOffset.y+13, 0xffffff, false);
*/

	// ��ڲ԰���W�̕\��
//	DrawFormatString(0, 40, 0xffffff, "PLAYER = %d %d", player.pos);
}