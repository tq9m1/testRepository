#include "DxLib.h"
#include "main.h"
#include "keyCheck.h"

bool newKey[KEY_MAX];
bool trgKey[KEY_MAX];
bool upKey[KEY_MAX];
bool oldKey[KEY_MAX];

// ----- �Ƃ肠�����S���ر
void KeyCheckSystemInit(void)
{
	for (int i = 0; i < KEY_MAX; i++) {
		newKey[i] = false;
		trgKey[i] = false;
		upKey[i] = false;
		oldKey[i] = false;
	}
}


void KeyCheck(void)
{
	// ----- newKey
	for (int i = 0; i < KEY_MAX; i++) {
		newKey[i] = false;	// �S�������Ă��Ȃ����Ƃɂ���
		trgKey[i] = false;	// �S�������Ă��Ȃ����Ƃɂ���
		upKey[i] = false;	// �S�������Ă��Ȃ����Ƃɂ���
	}

	if (CheckHitKey(KEY_INPUT_W)) newKey[P1_UP] = true;
	if (CheckHitKey(KEY_INPUT_D)) newKey[P1_RIGHT] = true;
	if (CheckHitKey(KEY_INPUT_S)) newKey[P1_DOWN] = true;
	if (CheckHitKey(KEY_INPUT_A)) newKey[P1_LEFT] = true;

	if (CheckHitKey(KEY_INPUT_RCONTROL)) newKey[P1_RCTR] = true;
	if (CheckHitKey(KEY_INPUT_LCONTROL)) newKey[LCTR] = true;

	if (CheckHitKey(KEY_INPUT_P)) newKey[PAUSE] = true;
	if (CheckHitKey(KEY_INPUT_SPACE)) newKey[SPACE] = true;

/* ======= ����͎g��Ȃ�
	if (CheckHitKey(KEY_INPUT_UP)) newKey[P1_UP] = true;
	if (CheckHitKey(KEY_INPUT_RIGHT)) newKey[P1_RIGHT] = true;
	if (CheckHitKey(KEY_INPUT_DOWN)) newKey[P1_DOWN] = true;
	if (CheckHitKey(KEY_INPUT_LEFT)) newKey[P1_LEFT] = true;

	if (CheckHitKey(KEY_INPUT_W)) newKey[P2_UP] = true;
	if (CheckHitKey(KEY_INPUT_D)) newKey[P2_RIGHT] = true;
	if (CheckHitKey(KEY_INPUT_S)) newKey[P2_DOWN] = true;
	if (CheckHitKey(KEY_INPUT_A)) newKey[P2_LEFT] = true;
*/

	// trgKey & upKey & oldKey
	for (int i = 0; i < KEY_MAX; i++) {
		trgKey[i] = newKey[i] & ~oldKey[i];	// trgKey
		upKey[i] = ~newKey[i] & oldKey[i];	// upKey
		oldKey[i] = newKey[i];		// oldKey
	}
}