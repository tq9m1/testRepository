#include "DxLib.h"
#include "main.h"
#include "keycheck.h"
#include "player.h"
#include "shot.h"

// �ϐ��錾
int playerImage;
CHARACTER player;


// �摜������
void PlayerSystemInit(void)
{
	playerImage = LoadGraph("image/player.png");
}

// �ϐ�������
void PlayerGameInit(void)
{
	player.visible = true;
	player.pos = { 20,SCREEN_SIZE_Y / 2 };
	player.size = { 32,32 };
	player.sizeOffset = { player.size.x / 2, player.size.y / 2 };
	player.moveSpeed = 6;
	player.lifeMax = 20;
	player.life = player.lifeMax;
	player.shotFlag = false;
	player.damageFlag = false;
	player.rad = PI_F / 180;
}

// ���쏈��
void PlayerControl(void)
{
	// ---------- ��ڲ԰����
	bool playerMoved = false;
	// �E�ړ�
	if (newKey[P1_RIGHT]) {
		playerMoved = true;
		player.pos.x += player.moveSpeed;
	}
	// ���ړ�
	if (newKey[P1_LEFT]){
		playerMoved = true;
		player.pos.x -= player.moveSpeed;
	}
	// ��ړ�
	if (newKey[P1_UP]) {
		playerMoved = true;
		player.pos.y -= player.moveSpeed;
	}
	// ���ړ�
	if (newKey[P1_DOWN]) {
		playerMoved = true;
		player.pos.y += player.moveSpeed;
	}

	// ----- �ړ�����
	// �E
	if (player.pos.x > SCREEN_SIZE_X - player.size.x / 2) {
		player.pos.x = SCREEN_SIZE_X - player.size.x / 2;
	}
	// ��
	if (player.pos.x < player.size.x / 2) {
		player.pos.x = player.size.x / 2;
	}
	// ��
	if (player.pos.y < player.size.y / 2) {
		player.pos.y = player.size.y / 2;
	}
	// ��
	if (player.pos.y > SCREEN_SIZE_Y - player.size.y / 2) {
		player.pos.y = SCREEN_SIZE_Y - player.size.y / 2;
	}
}

// �����蔻��
bool PlayerHitCheck(XY_F ePos, XY_F eSize)
{
	if ((player.visible) && (player.damageFlag == false)) {
		if (((player.pos.x + player.sizeOffset.x - 12) >= (ePos.x - eSize.x))
			&& ((player.pos.x - player.sizeOffset.x + 12) <= (ePos.x + eSize.x))
			&& ((player.pos.y + player.sizeOffset.y - 12) >= (ePos.y - eSize.y))
			&& ((player.pos.y - player.sizeOffset.y + 12) <= (ePos.y + eSize.y)))
		{
			player.life--;
			player.damageFlag = true;
			if (player.life == 0) {
				player.visible = false;
			}
			return true;
		}
	}
	return player.damageFlag = false;
}

// �`�揈��
void PlayerDraw(void)
{
	// ��ڲ԰�̕\��
	if (player.visible) {
		DrawRotaGraph(player.pos.x - player.sizeOffset.x / 2 + 8,
			player.pos.y - player.sizeOffset.y / 2 + 8,
			1.0f, player.rad * 90, playerImage, true);
	}

	/* ----- �����蔻�蒲���p
	DrawBox(player.pos.x - player.sizeOffset.x + 12, player.pos.y + player.sizeOffset.y - 12,
		player.pos.x + player.sizeOffset.x - 12, player.pos.y - player.sizeOffset.y + 12, 0xffffff, true);

	// ��ڲ԰���W�̕\��
	//DrawFormatString(0, 40, 0xffffff, "PLAYER = %d %d", player.pos);
	*/
	DrawFormatString(0, 20, 0xffffff, "LIFE = %d", player.life);
}